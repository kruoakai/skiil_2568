A5 Teaching Set (generated 2025-08-24T05:22:03)
------------------------------------------------------------
Included files:
1) Worksheets_A5_StudentLabs.docx — 4 ใบงาน + Rubric (25 คะแนน/ชุด)
2) ERD_A5_detailed.png — ERD พร้อมระบุ PK/ความสัมพันธ์
3) a5_compose_stack.zip — Docker Compose (MySQL + API + phpMyAdmin + init schema)
4) Slides_A5_Teaching.pdf — สไลด์สรุปใช้สอน

Quick start (Compose):
- แตก a5_compose_stack.zip → เปิดโฟลเดอร์
- docker compose up -d --build
- API: http://localhost:7000/system/health
- phpMyAdmin: http://localhost:8081 (root / rootpassword)