const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const uploadDir = process.env.UPLOAD_DIR || 'uploads';
app.use('/uploads', express.static(path.join(__dirname, '..', uploadDir)));

app.get('/system/health', async (req, res) => {
  const db = require('./config/db');
  try {
    const conn = await db.getConnection();
    await conn.ping();
    conn.release();
    res.json({ ok: true, db: 'up', time: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/results', require('./routes/results.routes'));
app.use('/api/reports', require('./routes/reports.routes'));
app.use('/api/attachments', require('./routes/attachments.routes'));

const PORT = process.env.PORT || 7000;
app.listen(PORT, () => console.log('API running on http://localhost:' + PORT));