const multer = require('multer');
const path = require('path');
const fs = require('fs');
const uploadDir = process.env.UPLOAD_DIR || 'uploads';
const finalDir = path.join(__dirname, '..', uploadDir);
if (!fs.existsSync(finalDir)) { fs.mkdirSync(finalDir, { recursive: true }); }
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, finalDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '');
    cb(null, 'std-it' + Date.now() + ext);
  }
});
module.exports = multer({ storage });