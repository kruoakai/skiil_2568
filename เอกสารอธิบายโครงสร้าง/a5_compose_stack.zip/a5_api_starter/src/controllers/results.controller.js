const db = require('../config/db');
async function hasRequiredEvidence(period_id, evaluatee_id, indicator_id) {
  const [m] = await db.query('SELECT COUNT(*) AS m FROM indicator_evidence WHERE indicator_id=?', [indicator_id]);
  if (!m[0].m) return true;
  const [a] = await db.query(
    'SELECT COUNT(*) AS c FROM attachments WHERE period_id=? AND evaluatee_id=? AND indicator_id=?',
    [period_id, evaluatee_id, indicator_id]
  );
  return a[0].c > 0;
}
exports.submitResult = async (req, res) => {
  const id = parseInt(req.params.id,10);
  if (!id) return res.status(400).json({ error: 'invalid id' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT id, period_id, evaluatee_id, indicator_id, status FROM evaluation_results WHERE id=? FOR UPDATE', [id]);
    if (!rows.length) { await conn.rollback(); return res.status(404).json({ error: 'result not found' }); }
    const r = rows[0];
    if (r.status === 'submitted') { await conn.rollback(); return res.status(400).json({ error: 'already submitted' }); }
    const ok = await hasRequiredEvidence(r.period_id, r.evaluatee_id, r.indicator_id);
    if (!ok) { await conn.rollback(); return res.status(400).json({ error: 'evidence required before submit' }); }
    await conn.query("UPDATE evaluation_results SET status='submitted', submitted_at=NOW() WHERE id=?", [id]);
    await conn.commit();
    return res.json({ ok: true, id, status: 'submitted' });
  } catch (e) {
    await conn.rollback();
    return res.status(500).json({ error: e.message });
  } finally { conn.release(); }
}