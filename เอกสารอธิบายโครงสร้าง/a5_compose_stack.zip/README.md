ดู docker-compose.yml และ a5_api_starter/ สำหรับการใช้งาน
