const db = require('../config/db');

// normalize helper for score_1_4 / yes_no / file_url
function normValue(row) {
  if (row.type === 'score_1_4') {
    if (row.score == null) return 0;
    return Math.max(0, Math.min(1, (row.score - 1) / 3));
  }
  if (row.type === 'yes_no') {
    return row.value_yes_no ? 1 : 0;
  }
  if (row.type === 'file_url') {
    // treat as 1 if there is at least one attachment record for this result
    return row.attach_count && row.attach_count > 0 ? 1 : 0;
  }
  return 0;
}

exports.normalized = async (req, res) => {
  const period = parseInt(req.query.period,10);
  const evaluatee = parseInt(req.query.evaluatee,10);
  if (!period || !evaluatee) return res.status(400).json({ error: 'period & evaluatee are required' });

  try {
    // fetch results + indicator info + attachments count
    const [rows] = await db.query(`
      SELECT er.id, er.topic_id, er.indicator_id, er.score, er.value_yes_no,
             i.type, i.weight AS indicator_weight, t.weight AS topic_weight,
             (SELECT COUNT(*) FROM attachments a
              WHERE a.period_id=er.period_id AND a.evaluatee_id=er.evaluatee_id AND a.indicator_id=er.indicator_id) AS attach_count
      FROM evaluation_results er
      JOIN indicators i ON i.id = er.indicator_id
      JOIN evaluation_topics t ON t.id = er.topic_id
      WHERE er.period_id=? AND er.evaluatee_id=?
    `, [period, evaluatee]);

    // group by topic
    const byTopic = {};
    for (const r of rows) {
      const v = normValue(r);
      if (!byTopic[r.topic_id]) byTopic[r.topic_id] = { sumW: 0, sum: 0, topicWeight: r.topic_weight };
      byTopic[r.topic_id].sumW += (r.indicator_weight || 0);
      byTopic[r.topic_id].sum += v * (r.indicator_weight || 0);
    }

    let total = 0;
    let detail = [];
    for (const [topicId, obj] of Object.entries(byTopic)) {
      const topicW = obj.topicWeight || 0;
      const topicScore01 = obj.sumW > 0 ? (obj.sum / obj.sumW) : 0; // 0..1
      const topicScoreScaled = topicScore01 * topicW; // assume topicWeight sums to 60
      total += topicScoreScaled;
      detail.push({ topic_id: parseInt(topicId,10), topic_weight: topicW, score_0_1: topicScore01, score_scaled: topicScoreScaled });
    }

    return res.json({ period, evaluatee, total_normalized_over_60: total, topics: detail });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
};

exports.progress = async (req, res) => {
  const period = parseInt(req.query.period,10);
  const dept = parseInt(req.query.dept,10);
  if (!period || !dept) return res.status(400).json({ error: 'period & dept are required' });
  try {
    const [rows] = await db.query(`
      SELECT u.id AS evaluatee_id, u.name_th, COUNT(*) AS total, SUM(er.status='submitted') AS submitted,
             ROUND(100 * SUM(er.status='submitted') / NULLIF(COUNT(*),0), 2) AS percent
      FROM evaluation_results er
      JOIN users u ON u.id = er.evaluatee_id
      WHERE er.period_id=? AND u.department_id=?
      GROUP BY u.id, u.name_th
      ORDER BY u.name_th
    `, [period, dept]);
    return res.json({ period, dept, summary: rows });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
};