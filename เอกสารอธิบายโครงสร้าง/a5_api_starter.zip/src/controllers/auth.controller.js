const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'email & password required' });

    const [rows] = await db.query('SELECT id, email, password, role, status, department_id FROM users WHERE email=?', [email]);
    if (!rows.length) return res.status(401).json({ error: 'invalid credentials' });

    const user = rows[0];
    if (user.status && user.status !== 'active') return res.status(403).json({ error: 'user disabled' });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ error: 'invalid credentials' });

    const token = jwt.sign({ uid: user.id, role: user.role, dept: user.department_id }, process.env.JWT_SECRET, { expiresIn: '8h' });
    return res.json({ token });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}