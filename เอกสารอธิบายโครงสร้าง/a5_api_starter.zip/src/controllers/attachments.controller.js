const db = require('../config/db');
const path = require('path');

exports.upload = async (req, res) => {
  try {
    const { period_id, evaluatee_id, indicator_id, evidence_type_id } = req.body || {};
    if (!req.file) return res.status(400).json({ error: 'missing file' });
    if (!period_id || !evaluatee_id || !indicator_id || !evidence_type_id) {
      return res.status(400).json({ error: 'missing metadata fields' });
    }
    const { filename, mimetype, size } = req.file;
    const storage_path = path.join('uploads', filename);
    await db.query(`
      INSERT INTO attachments (period_id, evaluatee_id, indicator_id, evidence_type_id, file_name, mime_type, size_bytes, storage_path, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `, [period_id, evaluatee_id, indicator_id, evidence_type_id, filename, mimetype, size, storage_path]);
    return res.json({ ok: true, file: filename, path: '/uploads/' + filename });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
};