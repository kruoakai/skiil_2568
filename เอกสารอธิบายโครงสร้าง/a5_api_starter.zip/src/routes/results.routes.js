const router = require('express').Router();
const { auth } = require('../middlewares/auth');
const ctrl = require('../controllers/results.controller');

// submit result (requires evidence if mapping exists)
router.post('/:id/submit', auth(['evaluator','admin']), ctrl.submitResult);

module.exports = router;