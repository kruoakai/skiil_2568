const router = require('express').Router();
const { auth } = require('../middlewares/auth');
const ctrl = require('../controllers/reports.controller');

router.get('/normalized', auth(['admin','evaluator']), ctrl.normalized);
router.get('/progress', auth(['admin']), ctrl.progress);

module.exports = router;