const router = require('express').Router();
const { auth } = require('../middlewares/auth');
const ctrl = require('../controllers/attachments.controller');
const upload = require('../utils/multer');

router.post('/upload', auth(['evaluatee','evaluator','admin']), upload.single('file'), ctrl.upload);

module.exports = router;