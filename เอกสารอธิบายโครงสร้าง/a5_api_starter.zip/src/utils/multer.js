const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDir = process.env.UPLOAD_DIR || 'uploads';
if (!fs.existsSync(path.join(__dirname, '..', uploadDir))) {
  fs.mkdirSync(path.join(__dirname, '..', uploadDir), { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '..', uploadDir));
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '');
    const base = 'std-it' + Date.now();
    cb(null, base + ext);
  }
});

module.exports = multer({ storage });