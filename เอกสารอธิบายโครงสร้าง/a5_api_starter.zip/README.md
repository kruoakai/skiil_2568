# A5 API Starter

Minimal Express + MySQL2 + JWT + Multer to align with A5 schema.

## Run
1. `npm i`
2. copy `.env.example` -> `.env` and set values
3. `npm run start`

## Endpoints
- `GET /system/health`
- `POST /api/auth/login` { email, password }
- `POST /api/results/:id/submit`
- `GET /api/reports/normalized?period=1&evaluatee=2`
- `GET /api/reports/progress?period=1&dept=10`
- `POST /api/attachments/upload` (form-data: file, period_id, evaluatee_id, indicator_id, evidence_type_id)