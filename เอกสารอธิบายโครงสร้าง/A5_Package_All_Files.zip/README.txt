A5 Package — All Files
Included:
- schema.md (Data Dictionary & Schema Guide)
- A5_Rubric_Backend_Frontend_DevOps.docx (Full rubric)
- A5_Rubric_Frontend_F1_F6_Checklist_Full.docx (Frontend checklists)
- A5_Rubric_Backend_B1_B6_Checklist_Full.docx (Backend checklists)
- 02_schema.sql (original schema)
- A5_อลงกรณ์ส่ง.docx (original spec)
- plus alternate formats (schema_A5_guide.md, schema.txt) if present
