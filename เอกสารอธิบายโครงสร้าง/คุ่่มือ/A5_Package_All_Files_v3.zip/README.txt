A5 Package (v3) — รวมทุกไฟล์ล่าสุด
- schema.md / schema_A5_guide.md / schema.txt
- A5_Rubric_Backend_Frontend_DevOps.docx
- A5_Rubric_Backend_B1_B6_Checklist_Full.docx
- A5_Rubric_Frontend_F1_F6_Checklist_Full.docx
- A5_Rubric_Frontend_Update_F1F2_Checklist.docx
- A5_Rubric_Manuals_User_Admin_Checklist.docx
- 02_schema.sql / A5_อลงกรณ์ส่ง.docx
