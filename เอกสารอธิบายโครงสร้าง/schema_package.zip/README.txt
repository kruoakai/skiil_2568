This package includes schema.md and (if available) 02_schema.sql.
