const router = require('express').Router();
const auth = require('../middlewares/auth');
const upload = require('../middlewares/upload');
const ctrl = require('../controllers/upload.controller');

// Evaluatee
router.post('/evidence', auth('evaluatee'), upload.single('file'), ctrl.uploadSelf);
router.get('/mine', auth('evaluatee'), ctrl.listMine);
router.put('/:id/file', auth('evaluatee','admin'), upload.single('file'), ctrl.replaceFile);
router.patch('/:id', auth('evaluatee','admin'), ctrl.patchMeta);
router.delete('/:id', auth('evaluatee','admin'), ctrl.remove);

// Evaluator
router.get('/evaluatee/:evaluateeId', auth('evaluator'), ctrl.listAssigned);

// Admin
router.post('/admin/evidence', auth('admin'), upload.single('file'), (req,res)=>{
  // reuse create with explicit evaluatee_id
  req.user = { ...(req.user||{}), sub: Number(req.body.evaluatee_id) }; // set owner to path
  require('../controllers/upload.controller').uploadSelf(req,res);
});
router.get('/admin', auth('admin'), ctrl.adminList);

module.exports = router;
