# Backend Minimal for A5 Upload

## Setup
```bash
cd backend-minimal
cp .env.example .env
npm install
npm start
```
- เริ่มที่ http://localhost:7000
- Swagger UI: http://localhost:7000/docs

## Sample JWT (เซ็นด้วย `JWT_SECRET=changeme`)
- EVALUATEE: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX...[snip]
- EVALUATOR: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX...[snip]
- ADMIN:     eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX...[snip]

โทเค็นฉบับเต็มถูกใส่ในไฟล์ Environment ของ Postman แล้ว
