const path = require('path'); const fs = require('fs');
const repo = require('../repositories/attachments');
const assignments = require('../repositories/assignments');
const mapping = require('../repositories/indicatorEvidence');

function ensureMapping(indicator_id, evidence_type_id){
  if (!mapping.isAllowed(indicator_id, evidence_type_id)){
    const err = new Error('Unsupported evidence type for indicator'); err.status=415; throw err;
  }
}

exports.uploadSelf = (req, res) => {
  try {
    const { period_id, indicator_id, evidence_type_id } = req.body || {};
    if (!period_id || !indicator_id || !evidence_type_id) return res.status(400).json({ success:false, message:'Missing fields'});
    ensureMapping(String(indicator_id), String(evidence_type_id));
    const f = req.file;
    if (!f) return res.status(400).json({ success:false, message:'Missing file'});
    const row = repo.create({
      period_id: Number(period_id),
      evaluatee_id: req.user.sub,
      indicator_id: Number(indicator_id),
      evidence_type_id: Number(evidence_type_id),
      file_name: path.basename(f.filename),
      mime_type: f.mimetype,
      size_bytes: f.size,
      storage_path: f.path
    });
    res.json({ success:true, data: row });
  } catch(e){
    res.status(e.status || 500).json({ success:false, message:e.message });
  }
};

exports.listMine = (req, res) => {
  const { period_id, indicator_id } = req.query || {};
  if (!period_id) return res.status(400).json({ success:false, message:'period_id required'});
  const rows = repo.query({ period_id: Number(period_id), evaluatee_id: req.user.sub, indicator_id: indicator_id? Number(indicator_id): undefined });
  res.json({ success:true, data: rows });
};

exports.replaceFile = (req, res) => {
  const { id } = req.params;
  const f = req.file;
  if (!f) return res.status(400).json({ success:false, message:'Missing file'});
  const row = repo.findById(id);
  if (!row) return res.status(404).json({ success:false, message:'Not Found'});
  if (req.user.role === 'evaluatee' && row.evaluatee_id !== req.user.sub) return res.status(403).json({ success:false, message:'Forbidden'});
  // remove old file
  try { if (row.storage_path && fs.existsSync(row.storage_path)) fs.unlinkSync(row.storage_path); } catch {}
  const updated = repo.update(id, {
    file_name: path.basename(f.filename),
    mime_type: f.mimetype,
    size_bytes: f.size,
    storage_path: f.path
  });
  res.json({ success:true, data: updated });
};

exports.patchMeta = (req, res) => {
  const { id } = req.params;
  const row = repo.findById(id);
  if (!row) return res.status(404).json({ success:false, message:'Not Found'});
  if (req.user.role === 'evaluatee' && row.evaluatee_id !== req.user.sub) return res.status(403).json({ success:false, message:'Forbidden'});
  const patch = {};
  for (const k of ['period_id','evaluatee_id','indicator_id','evidence_type_id']){
    if (req.body[k] != null) patch[k] = Number(req.body[k]);
  }
  if (patch.indicator_id || patch.evidence_type_id){
    const ind = String(patch.indicator_id || row.indicator_id);
    const evt = String(patch.evidence_type_id || row.evidence_type_id);
    if (!mapping.isAllowed(ind, evt)) return res.status(415).json({ success:false, message:'Unsupported evidence type for indicator'});
  }
  const updated = repo.update(id, patch);
  res.json({ success:true, data: updated });
};

exports.remove = (req, res) => {
  const { id } = req.params;
  const row = repo.findById(id);
  if (!row) return res.status(404).json({ success:false, message:'Not Found'});
  if (req.user.role === 'evaluatee' && row.evaluatee_id !== req.user.sub) return res.status(403).json({ success:false, message:'Forbidden'});
  try { if (row.storage_path && fs.existsSync(row.storage_path)) fs.unlinkSync(row.storage_path); } catch {}
  repo.remove(id);
  res.json({ success:true });
};

exports.listAssigned = (req, res) => {
  const { evaluateeId } = req.params;
  const { period_id } = req.query;
  if (!period_id) return res.status(400).json({ success:false, message:'period_id required'});
  if (!assignments.hasEvaluatee(Number(period_id), req.user.sub, Number(evaluateeId))) {
    return res.status(403).json({ success:false, message:'Not assigned'});
  }
  const rows = repo.query({ period_id: Number(period_id), evaluatee_id: Number(evaluateeId) });
  res.json({ success:true, data: rows });
};

exports.adminList = (req, res) => {
  const q = {};
  ['period_id','evaluatee_id','indicator_id'].forEach(k=>{
    if (req.query[k] != null) q[k] = Number(req.query[k]);
  });
  res.json({ success:true, data: repo.query(q) });
};

