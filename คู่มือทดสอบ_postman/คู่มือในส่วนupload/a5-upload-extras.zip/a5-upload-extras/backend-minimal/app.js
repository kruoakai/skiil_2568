const express = require('express');
const fs = require('fs'); const path = require('path');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');

const app = express();
app.use(express.json());
app.use(cors({
  origin: (process.env.CORS_ORIGIN || '').split(',').filter(Boolean)
}));

// static files (uploads)
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  immutable: true, maxAge: '30d',
  setHeaders: (res) => res.setHeader('X-Content-Type-Options','nosniff')
}));

// routes
app.get('/health', (req, res) => res.json({ ok: true }));
app.use('/api/upload', require('./routes/upload.routes'));

// swagger
try {
  const openapi = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'openapi_full.json'), 'utf-8'));
  app.get('/openapi.json', (req,res)=> res.json(openapi));
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi));
} catch(e) {
  console.warn('OpenAPI not found, skip /docs');
}
module.exports = app;
