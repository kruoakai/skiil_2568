# คู่มือการทดสอบระบบ A5 (Upload + Users) — Jest/Supertest & Postman/CI

> เอกสารนี้ออกแบบสำหรับ **ครู/ผู้ตรวจงาน/นักศึกษา** เพื่อทดสอบระบบ A5 ที่ประกอบด้วยโมดูล **Upload (Attachments)** และ **Users** บนโปรเจกต์ `a5-upload-extras-integrated`  
> ครอบคลุม: การเตรียมแวดล้อม, การรันทดสอบ (unit/e2e), โครงสร้างไฟล์เทสต์, Test Matrix, เคสสำคัญด้านความปลอดภัย/ความถูกต้อง, Postman/Newman, Coverage, และ CI Pipeline (GitHub Actions)

---

## 1) ภาพรวมและวัตถุประสงค์
- ยืนยันว่าฟีเจอร์หลัก **ทำงานได้จริง** ตามสัญญา API และนโยบายบทบาท/สิทธิ์
- ลดการพึ่งพาการคลิกด้วยมือ → เปลี่ยนเป็น **เทสต์อัตโนมัติ**
- ให้เช็กลิสต์สั้น ๆ สำหรับ **ตรวจงานนักศึกษา** ได้ทันที และ **ประเมินคุณภาพ** ด้วย Coverage

### ขอบเขตที่ทดสอบ
- **Users routes** (ตามสคริปต์ของอาจารย์): controller 1/2, เส้นทาง `/:id?`, เงื่อนไข JWT/Role
- **Upload module**: upload → list → replace → patch → delete, admin on-behalf, evaluator view assigned, MIME reject

---

## 2) เตรียมแวดล้อม (Environment)
- Node.js ≥ 18.x และ npm ≥ 9.x
- แตกไฟล์ `a5-upload-extras-integrated.zip`
- ติดตั้งแพ็กเกจในโฟลเดอร์ `backend-minimal`:
```bash
npm --prefix backend-minimal install
```
- ตั้งค่า `.env` (ถ้าจะรันเซิร์ฟเวอร์):
```bash
cd backend-minimal
cp .env.example .env
# ปรับ PORT/JWT_SECRET/UPLOAD_MAX_MB/CORS_ORIGIN ตามต้องการ
```

> หมายเหตุ: เทสต์ **ไม่ต้อง**รันเซิร์ฟเวอร์จริง เพราะ Supertest จะ import `app` โดยตรง

---

## 3) รันทดสอบ
รันทั้งหมด (users + uploads):
```bash
npm --prefix backend-minimal run test
```
โหมดดูผลแบบต่อเนื่อง:
```bash
npm --prefix backend-minimal run test:watch
```

### Coverage
รันพร้อมวัดความครอบคลุมโค้ด (ปรับใน `jest.config.js` ตามต้องการ):
```bash
npx jest --config jest.config.js --coverage
```
ข้อเสนอแนะเบื้องต้น (ตั้งใน `package.json` หรือ `jest.config.js`):
```json
"coverageThreshold": {
  "global": { "branches": 70, "functions": 80, "lines": 80, "statements": 80 }
}
```

---

## 4) โครงสร้างไฟล์เทสต์ (ของแพ็ก integrated)
```
/tests/
  users.e2e.test.js     # ครอบคลุมทุก use cases ของ Users routes
  uploads.e2e.test.js   # ครอบคลุม flow ของ Upload module และกรณี error สำคัญ
jest.config.js          # ตั้งค่า Jest (roots -> tests, coverage ฯลฯ)

/backend-minimal/
  app.js                # Express app (import ในเทสต์)
  routes/, controllers/, middlewares/, repositories/  # โค้ดที่ถูกทดสอบ
```

### หลักการตั้งชื่อ/จัดประเภท
- `*.e2e.test.js` = ทดสอบ End-to-End แบบ **in-process** (ไม่เปิดพอร์ตจริง)
- หากเพิ่ม Unit Test (เช่นทดสอบ function เดี่ยว ๆ) แนะนำต่อท้ายชื่อ `*.unit.test.js`

---

## 5) Test Matrix (สรุปเคสที่ต้องมีอย่างน้อย)
### 5.1 Users
| เส้นทาง | สิทธิ์ | คาดหวัง |
|---|---|---|
| `GET /api/users/list2` | ต้องมี JWT บทบาท admin/evaluator/evaluatee | 401 เมื่อไม่มี token, 200 เมื่อมี |
| `GET /api/users/server2` | ต้องมี JWT | 200 |
| `GET /api/users/list2/:id` | public | 200 เมื่อพบ, 404 เมื่อไม่พบ |
| `GET /api/users/server` | ต้องมี JWT | 401 เมื่อไม่มี token, 200 เมื่อมี |
| `GET /api/users/` | ต้องมี JWT | 200 เมื่อได้บทบาทที่อนุญาต |
| `GET /api/users/:id` | public | 200/404 |
| `POST /api/users` | public | 201 เมื่อสร้างสำเร็จ |
| `PUT /api/users` (ไม่มี `:id`) | public | 400 |
| `PUT /api/users/:id` | public | 200 เมื่อแก้สำเร็จ |
| `DELETE /api/users/:id` | public | 200 เมื่อสำเร็จ, 404 เมื่อไม่พบ |

### 5.2 Upload
| เส้นทาง | สิทธิ์ | คาดหวัง |
|---|---|---|
| `POST /api/upload/evidence` | evaluatee | 200 เมื่อสำเร็จ, 400 เมื่อ body ไม่ครบ, 415 เมื่อ MIME ไม่อนุญาต |
| `GET /api/upload/mine` | evaluatee | 200, ต้องส่ง `period_id` |
| `PUT /api/upload/:id/file` | evaluatee/admin | 200 เมื่อสำเร็จ, 404 เมื่อไม่พบ, 403 เมื่อเจ้าของไม่ตรง |
| `PATCH /api/upload/:id` | evaluatee/admin | 200 เมื่อสำเร็จ, 415 เมื่อ mapping indicator↔evidence ผิด |
| `DELETE /api/upload/:id` | evaluatee/admin | 200 เมื่อสำเร็จ, 404 เมื่อไม่พบ |
| `GET /api/upload/evaluatee/:evaluateeId?period_id=` | evaluator | 200 เมื่อมี assignment, 403 เมื่อไม่มี |
| `POST /api/upload/admin/evidence` | admin | 200 เมื่อสำเร็จ |

---

## 6) แนวทางเขียนเทสต์แบบ *ยืนพื้นได้ทุกกลุ่ม*
### 6.1 Reset สภาพแวดล้อมก่อนแต่ละเทสต์
- ล้างไฟล์ JSON mock (เช่น `data_users.json`, `data_attachments.json`)
- ลบโฟลเดอร์ `uploads/` และสร้างใหม่ เพื่อไม่ให้เทสต์รบกวนกัน

ตัวอย่าง (มีแล้วในไฟล์เทสต์):
```js
beforeEach(()=>{
  fs.writeFileSync(usersDataPath, JSON.stringify(seed, null, 2));
});
```

### 6.2 สร้าง JWT ที่สอดคล้องกับ `JWT_SECRET`
- ระบบใช้ `JWT_SECRET=changeme` ตาม `.env.example`
- ฟังก์ชันช่วยสร้างในเทสต์ (มีตัวอย่างแล้ว):
```js
function signJWT(payload, secret='changeme'){
  const header = { alg:'HS256', typ:'JWT' };
  const h = Buffer.from(JSON.stringify(header)).toString('base64url');
  const p = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = require('crypto').createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}
```

### 6.3 อัปโหลดไฟล์ด้วย Supertest
```js
const pdfBuf = Buffer.from('%PDF-1.4\n%mock');
await request(app).post('/api/upload/evidence')
  .set('Authorization', `Bearer ${TOKEN}`)
  .field('period_id','1001').field('indicator_id','23').field('evidence_type_id','1')
  .attach('file', pdfBuf, { filename:'x.pdf', contentType:'application/pdf' });
```

### 6.4 จำลองข้อผิดพลาด Multer
- **MIME ไม่อนุญาต**: ตั้ง `contentType: 'application/octet-stream'` → คาดหวัง 415/400
- **ไฟล์ใหญ่เกิน**: ตั้ง `UPLOAD_MAX_MB=1` ใน `.env` แล้วแนบ buffer ขนาด > 1MB → คาดหวัง 413

### 6.5 ทดสอบ Role/Assignment
- Evaluator ที่ไม่มี assignment → `GET evaluatee/:id` ต้องได้ 403
- Evaluatee แทนที่ไฟล์ของคนอื่น → 403

---

## 7) โครงสร้างเทสต์ที่มีอยู่ (อธิบายทีละไฟล์)
### 7.1 `tests/users.e2e.test.js`
หัวข้อหลัก:
- การป้องกันด้วย JWT (401/403)
- เส้นทาง public (200/404)
- สร้าง/แก้ไข/ลบ ผู้ใช้ (201/200/404)
- กรณีพิเศษ: `PUT /api/users` แบบไม่มี `:id` → 400 (รองรับรูปแบบเส้นทาง `/:id?`)

### 7.2 `tests/uploads.e2e.test.js`
หัวข้อหลัก:
- Flow เต็ม: upload → list → replace → patch (mapping 31↔2) → delete
- Admin อัปโหลดแทน evaluatee แล้ว evaluator ที่ถูกมอบหมาย list ได้
- ปฏิเสธ MIME ไม่อนุญาต (415/400)
- (สามารถเพิ่ม) ทดสอบ header ความปลอดภัยของ static:
```js
const res = await request(app).get('/uploads/somepath/...');
expect(res.headers['x-content-type-options']).toBe('nosniff');
```

---

## 8) Postman & Newman (Manual/CLI)
### 8.1 Postman
- Import: `A5_Upload_API.postman_collection.json`, `A5_Upload_Env.postman_environment.json` (จากแพ็กก่อนหน้า)
- เลือก Environment แล้วปรับ `BASE` เป็น `http://localhost:7000`
- ทดสอบอัปโหลดโดยแนบไฟล์จริงจากเครื่อง

### 8.2 Newman (รันทดสอบ Collection บน CLI)
```bash
npm i -g newman
newman run postman/A5_Upload_API.postman_collection.json -e postman/A5_Upload_Env.postman_environment.json
```

> เหมาะสำหรับ “ทดสอบปลายทาง” หลังจากรันเซิร์ฟเวอร์จริง หรือใช้ใน CI ร่วมกับ Jest

---

## 9) เพิ่ม Unit Test (ตัวอย่างแนวทาง)
แม้โปรเจกต์นี้เน้น e2e แต่หากต้องการ **Unit Test** (เช่นทดสอบ controller แยกจากระบบไฟล์/Repo) ให้ mock โมดูลที่เข้าถึง I/O:
```js
jest.mock('../repositories/users', ()=>({
  list: jest.fn(()=> [{ id:1, name:'Mock' }])
}));
const ctrl = require('../controllers/users.controller');
// เรียก ctrl.list ด้วย req/res mock แล้วตรวจ shape ของ response
```

---

## 10) ข้อควรระวัง/กับดักที่พบบ่อย
- ลืม reset ไฟล์ JSON → เทสต์อาจพึ่งพาสถานะจากเทสต์ก่อนหน้า
- ใช้ secret คนละค่า → JWT verify ล้มเหลว (401)
- ตั้งค่า MIME type ผิดตอนแนบไฟล์ → ได้ 415 ตามตั้งใจหรือไม่
- Windows vs UNIX path: ใช้ `path.join` เสมอเมื่ออ้างพาธในเทสต์
- เวลา test: ระวัง async/await ให้ await ครบถ้วน (อย่าลืม `return` หรือ `await` ใน Promise)

---

## 11) CI Pipeline (GitHub Actions) — ตัวอย่าง
สร้างไฟล์ `.github/workflows/ci.yml` ใน repo:
```yaml
name: CI
on:
  push:
  pull_request:
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install deps
        run: npm --prefix backend-minimal ci
      - name: Run tests
        run: npm --prefix backend-minimal run test -- --coverage
      - name: Upload coverage artifact
        uses: actions/upload-artifact@v4
        with:
          name: coverage
          path: coverage/
```

---

## 12) เช็กลิสต์ตรวจงานนักศึกษา (1 หน้ากระดาษ)
- [ ] รัน `npm --prefix backend-minimal install` ผ่าน
- [ ] **Users**: เทสต์ 10 เคสใน `users.e2e.test.js` ผ่านครบ
- [ ] **Upload**: เทสต์ flow หลัก + MIME reject ผ่านครบ
- [ ] เคส 401/403/404/413/415 ครบถ้วน
- [ ] Coverage ≥ 80% (หรือเกณฑ์ที่ครูกำหนด)
- [ ] มี README วิธีรันชัดเจน
- [ ] (ถ้าเพิ่ม) Workflow CI ทำงานจริงบน PR

---

## 13) ภาคผนวก
### 13.1 ตัวช่วยสร้าง Buffer ไฟล์ใหญ่เพื่อทดสอบ 413
```js
const big = Buffer.alloc(2 * 1024 * 1024, 0); // 2MB
// ตั้งค่า UPLOAD_MAX_MB=1 ใน .env ก่อนทดสอบ
```

### 13.2 ตัวอย่าง curl สำหรับอัปโหลด
```bash
curl -X POST "http://localhost:7000/api/upload/evidence" \
  -H "Authorization: Bearer <TOKEN_EVALUATEE>" \
  -F "period_id=1001" -F "indicator_id=23" -F "evidence_type_id=1" \
  -F "file=@lesson_plan.pdf"
```

### 13.3 แนวทางขยายเทสต์
- เพิ่มเทสต์ **inactive period** (สมมติ flag ใน repo/DB) → ปฏิเสธการแก้ไข
- เพิ่มเทสต์ **checksum** หลังอัปโหลด (ถ้ามี)
- เพิ่มเทสต์ **rate limit / brute-force** (ถ้าใส่ middleware เพิ่ม)

---

> **สรุป**: ให้เริ่มจากรันชุดเทสต์ที่จัดไว้ (users + uploads) ให้ผ่านทั้งหมดก่อน จากนั้นค่อยเพิ่ม Unit Test เฉพาะจุด และตั้ง Threshold Coverage ตามระดับงานที่ต้องการ หากต้องการให้ผมเติม Unit Test เพิ่มอีกชั้น (mock I/O) หรือรวม Postman/Newman ใน CI ก็บอกผมได้เลยครับ