# A5 Upload + Users — เอกสารประกอบ
ยินดีต้อนรับสู่เอกสารระบบ **A5 (Upload + Users)**

- ดูคู่มือทดสอบอย่างละเอียดที่เมนู **Testing**
- API สเปก: เปิด `/docs` จากเซิร์ฟเวอร์ (Swagger UI)

## โครงสร้างย่อ
- `/backend-minimal` — โค้ด Express + Tests
- `/tests` — ชุด e2e และ unit
- `/postman` — คอลเลกชันสำหรับ Manual/CI
