const httpMocks = () => {
  const res = {};
  res.statusCode = 200;
  res.status = (code)=> { res.statusCode = code; return res; };
  res.jsonPayload = null;
  res.json = (obj)=> { res.jsonPayload = obj; return res; };
  return { req: { body:{}, params:{} }, res };
};

jest.mock('../backend-minimal/repositories/users', ()=> ({
  list: jest.fn(()=> [{ id:99, name:'MockUser'}]),
  findById: jest.fn((id)=> id==1? { id:1, name:'One'}: undefined),
  create: jest.fn((o)=> ({ id:123, ...o })),
  update: jest.fn((id,patch)=> id==1? ({ id:1, ...patch }): null),
  remove: jest.fn((id)=> id==1)
}));

const ctrl = require('../backend-minimal/controllers/users.controller');
const repo = require('../backend-minimal/repositories/users');

test('users.controller.list returns data from repo.list', ()=>{
  const { req, res } = httpMocks();
  ctrl.list(req,res);
  expect(res.statusCode).toBe(200);
  expect(res.jsonPayload.data[0].id).toBe(99);
});

test('users.controller.get 404 when not found', ()=>{
  const { req, res } = httpMocks();
  req.params.id = 999;
  ctrl.get(req,res);
  expect(res.statusCode).toBe(404);
});

test('users.controller.create 400 when missing fields', ()=>{
  const { req, res } = httpMocks();
  req.body = { name:'A' };
  ctrl.create(req,res);
  expect(res.statusCode).toBe(400);
});

test('users.controller.update 400 when missing id', ()=>{
  const { req, res } = httpMocks();
  ctrl.update(req,res);
  expect(res.statusCode).toBe(400);
});
