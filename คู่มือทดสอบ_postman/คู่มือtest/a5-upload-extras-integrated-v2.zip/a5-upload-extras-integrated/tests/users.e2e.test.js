const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend-minimal/app');

function b64urlJSON(obj){ return Buffer.from(JSON.stringify(obj)).toString('base64url'); }
function signJWT(payload, secret='changeme'){
  const header = { alg:'HS256', typ:'JWT' };
  const h = b64urlJSON(header); const p = b64urlJSON(payload);
  const crypto = require('crypto');
  const sig = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}

const TOKENS = {
  evaluatee: signJWT({ sub:101, role:'evaluatee', exp: 1893456000 }),
  evaluator: signJWT({ sub:201, role:'evaluator', exp: 1893456000 }),
  admin:     signJWT({ sub:1,   role:'admin',     exp: 1893456000 }),
};

const usersDataPath = path.join(__dirname, '..', 'backend-minimal', 'data_users.json');

beforeEach(()=>{
  const initial = [
    { id:1, name:'Alice', email:'alice@example.com', role:'evaluatee', password:'x', created_at: new Date().toISOString() },
    { id:2, name:'Evan',  email:'evan@example.com',  role:'evaluator', password:'y', created_at: new Date().toISOString() },
  ];
  fs.writeFileSync(usersDataPath, JSON.stringify(initial, null, 2));
});

describe('Users routes — controller 2', ()=>{
  test('GET /api/users/list2 requires auth -> 401 when missing', async ()=>{
    const res = await request(app).get('/api/users/list2');
    expect(res.status).toBe(401);
  });
  test('GET /api/users/list2 -> 200 with admin token', async ()=>{
    const res = await request(app).get('/api/users/list2').set('Authorization', `Bearer ${TOKENS.admin}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });
  test('GET /api/users/server2 -> 200 with evaluator token', async ()=>{
    const res = await request(app).get('/api/users/server2').set('Authorization', `Bearer ${TOKENS.evaluator}`);
    expect(res.status).toBe(200);
  });
  test('GET /api/users/list2/1 (no auth) -> 200', async ()=>{
    const res = await request(app).get('/api/users/list2/1');
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBe(1);
  });
  test('GET /api/users/list2/999 -> 404', async ()=>{
    const res = await request(app).get('/api/users/list2/999');
    expect(res.status).toBe(404);
  });
});

describe('Users routes — controller 1', ()=>{
  test('GET /api/users/server protected -> 401 when missing token', async ()=>{
    const res = await request(app).get('/api/users/server');
    expect(res.status).toBe(401);
  });
  test('GET /api/users/server -> 200 with evaluatee token', async ()=>{
    const res = await request(app).get('/api/users/server').set('Authorization', `Bearer ${TOKENS.evaluatee}`);
    expect(res.status).toBe(200);
  });
  test('GET /api/users/ (list) -> 200 with any role', async ()=>{
    const roles = [TOKENS.admin, TOKENS.evaluator, TOKENS.evaluatee];
    for (const t of roles){
      const res = await request(app).get('/api/users/').set('Authorization', `Bearer ${t}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data)).toBe(true);
    }
  });
  test('GET /api/users/1 (public) -> 200', async ()=>{
    const res = await request(app).get('/api/users/1');
    expect(res.status).toBe(200);
    expect(res.body.data.email).toBe('alice@example.com');
  });
  test('GET /api/users/999 -> 404', async ()=>{
    const res = await request(app).get('/api/users/999');
    expect(res.status).toBe(404);
  });
  test('POST /api/users (public create) -> 201', async ()=>{
    const res = await request(app).post('/api/users').send({ name:'Bob', email:'bob@example.com', role:'evaluatee', password:'z' });
    expect(res.status).toBe(201);
    expect(res.body.data.id).toBeGreaterThan(2);
  });
  test('PUT /api/users (no id) -> 400', async ()=>{
    const res = await request(app).put('/api/users').send({ name:'Alice2' });
    expect(res.status).toBe(400);
  });
  test('PUT /api/users/1 -> 200 and updates', async ()=>{
    const res = await request(app).put('/api/users/1').send({ name:'Alice2', role:'evaluatee' });
    expect(res.status).toBe(200);
    expect(res.body.data.name).toBe('Alice2');
  });
  test('DELETE /api/users/2 -> 200 then GET -> 404', async ()=>{
    const res = await request(app).delete('/api/users/2');
    expect(res.status).toBe(200);
    const res2 = await request(app).get('/api/users/2');
    expect(res2.status).toBe(404);
  });
  test('DELETE /api/users/999 -> 404', async ()=>{
    const res = await request(app).delete('/api/users/999');
    expect(res.status).toBe(404);
  });
});
