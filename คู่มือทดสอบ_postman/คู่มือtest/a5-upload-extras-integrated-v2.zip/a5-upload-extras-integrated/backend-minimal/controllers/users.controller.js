const usersRepo = require('../repositories/users');

exports.listServer = (req, res)=>{
  res.json({ success:true, data: { uptime: process.uptime(), env: process.env.NODE_ENV || 'development' } });
};

exports.list = (req, res)=>{
  res.json({ success:true, data: usersRepo.list() });
};

exports.get = (req, res)=>{
  const row = usersRepo.findById(req.params.id);
  if (!row) return res.status(404).json({ success:false, message:'Not Found' });
  res.json({ success:true, data: row });
};

exports.create = (req, res)=>{
  const { name, email, role, password } = req.body || {};
  if (!name || !email || !role) return res.status(400).json({ success:false, message:'Missing fields' });
  const row = usersRepo.create({ name, email, role, password });
  res.status(201).json({ success:true, data: row });
};

exports.update = (req, res)=>{
  const id = req.params.id;
  if (!id) return res.status(400).json({ success:false, message:'Missing user ID' });
  const { name, email, role, password } = req.body || {};
  const updated = usersRepo.update(id, { name, email, role, password });
  if (!updated) return res.status(404).json({ success:false, message:'Not Found' });
  res.json({ success:true, data: updated });
};

exports.remove = (req, res)=>{
  const id = req.params.id;
  const ok = usersRepo.remove(id);
  if (!ok) return res.status(404).json({ success:false, message:'Not Found' });
  res.json({ success:true });
};
