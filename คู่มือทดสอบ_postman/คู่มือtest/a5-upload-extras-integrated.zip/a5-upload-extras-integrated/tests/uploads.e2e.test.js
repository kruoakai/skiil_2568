const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend-minimal/app');

function b64urlJSON(obj){ return Buffer.from(JSON.stringify(obj)).toString('base64url'); }
function signJWT(payload, secret='changeme'){
  const header = { alg:'HS256', typ:'JWT' };
  const h = b64urlJSON(header); const p = b64urlJSON(payload);
  const crypto = require('crypto');
  const sig = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}

const TOKENS = {
  evaluatee101: signJWT({ sub:101, role:'evaluatee', exp: 1893456000 }),
  evaluator201: signJWT({ sub:201, role:'evaluator', exp: 1893456000 }),
  admin1:       signJWT({ sub:1,   role:'admin',     exp: 1893456000 }),
};

const attachmentsDataPath = path.join(__dirname, '..', 'backend-minimal', 'data_attachments.json');

beforeEach(()=>{
  fs.writeFileSync(attachmentsDataPath, JSON.stringify([], null, 2));
  // clean uploads folder
  const up = path.join(__dirname, '..', 'backend-minimal', 'uploads');
  fs.rmSync(up, { recursive:true, force:true });
  fs.mkdirSync(up, { recursive: true });
});

test('Evaluatee upload -> list -> replace -> patch -> delete', async ()=>{
  // upload
  const pdfBuf = Buffer.from('%PDF-1.4\n%mock');
  let res = await request(app).post('/api/upload/evidence')
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`)
    .field('period_id','1001').field('indicator_id','23').field('evidence_type_id','1')
    .attach('file', pdfBuf, { filename:'test.pdf', contentType: 'application/pdf' });
  expect(res.status).toBe(200);
  const id = res.body.data.id;

  // list mine
  res = await request(app).get('/api/upload/mine?period_id=1001')
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`);
  expect(res.status).toBe(200);
  expect(res.body.data.find(x=> x.id === id)).toBeTruthy();

  // replace file
  const pdf2 = Buffer.from('%PDF-1.4\n%mock2');
  res = await request(app).put(`/api/upload/${id}/file`)
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`)
    .attach('file', pdf2, { filename:'test2.pdf', contentType: 'application/pdf' });
  expect(res.status).toBe(200);

  // patch meta (change to indicator 31/2 mapping)
  res = await request(app).patch(`/api/upload/${id}`)
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`)
    .send({ indicator_id: 31, evidence_type_id: 2 });
  expect(res.status).toBe(200);

  // delete
  res = await request(app).delete(`/api/upload/${id}`)
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`);
  expect(res.status).toBe(200);
});

test('Unsupported MIME should be rejected (415/400)', async ()=>{
  const buf = Buffer.from('dummy');
  const res = await request(app).post('/api/upload/evidence')
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`)
    .field('period_id','1001').field('indicator_id','23').field('evidence_type_id','1')
    .attach('file', buf, { filename:'x.exe', contentType: 'application/octet-stream' });
  expect([400,415]).toContain(res.status);
});

test('Admin upload on behalf + Evaluator list assigned', async ()=>{
  // admin upload for evaluatee 55
  const pdf = Buffer.from('%PDF-1.4\n%mock');
  let res = await request(app).post('/api/upload/admin/evidence')
    .set('Authorization', `Bearer ${TOKENS.admin1}`)
    .field('evaluatee_id','55').field('period_id','1001').field('indicator_id','23').field('evidence_type_id','1')
    .attach('file', pdf, { filename:'a.pdf', contentType: 'application/pdf' });
  expect(res.status).toBe(200);

  // evaluator list assigned (201 ↔ 55 paired in mock assignments)
  res = await request(app).get('/api/upload/evaluatee/55?period_id=1001')
    .set('Authorization', `Bearer ${TOKENS.evaluator201}`);
  expect(res.status).toBe(200);
  expect(Array.isArray(res.body.data)).toBe(true);
});
