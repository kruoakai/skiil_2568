# A5 Upload + Users — Minimal Backend + Jest/Supertest Tests

## รันเซิร์ฟเวอร์
```bash
cd backend-minimal
cp .env.example .env
npm install
npm start
# http://localhost:7000  | Swagger: http://localhost:7000/docs
```

## รันทดสอบ (users + uploads)
จากโฟลเดอร์ราก (ที่มี jest.config.js):
```bash
npm --prefix backend-minimal install
npm --prefix backend-minimal run test
# หรือแบบ watch
npm --prefix backend-minimal run test:watch
```

## ครอบคลุม
- Users routes (ตามสคริปต์ของคุณ): controller1/controller2, สิทธิ์ JWT, เคส `/:id?`
- Upload module: upload/list/replace/patch/delete, admin on-behalf, evaluator view assigned, MIME reject

> หมายเหตุ: ใช้ mock persistence ด้วยไฟล์ JSON และโฟลเดอร์ `uploads/`
