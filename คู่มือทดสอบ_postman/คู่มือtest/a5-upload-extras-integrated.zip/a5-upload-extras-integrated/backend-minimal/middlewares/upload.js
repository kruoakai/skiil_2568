const multer = require('multer');
const path = require('path'); const fs = require('fs');

const MAX_MB = parseInt(process.env.UPLOAD_MAX_MB || '20', 10) * 1024 * 1024;
const ALLOWED = new Set(['application/pdf','image/png','image/jpeg','image/webp']);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const body = req.body || {};
    const evaluatee_id = body.evaluatee_id || (req.user && req.user.sub);
    const period_id = body.period_id;
    const dir = path.join(__dirname, '..', 'uploads', String(period_id || 'unknown'), String(evaluatee_id || 'unknown'));
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const safe = path.parse(file.originalname).name.replace(/[^a-zA-Z0-9_-]/g,'_');
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}_${safe}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  if (!ALLOWED.has(file.mimetype)) return cb(new Error('Unsupported file type'), false);
  cb(null, true);
}

module.exports = multer({ storage, fileFilter, limits: { fileSize: MAX_MB } });
