const router = require('express').Router();
const auth = require('../middlewares/auth');
const ctrl = require('../controllers/users.controller');
const ctrl2 = require('../controllers/users.controller2');

// ทางเลือกใช้ controller ตัวที่ 2
//enum('admin', 'evaluator', 'evaluatee')
router.get('/list2',   auth('admin','evaluator','evaluatee'), ctrl2.list2);
router.get('/server2', auth('admin','evaluator','evaluatee'), ctrl2.listServer);
router.get('/list2/:id', ctrl2.get);

// ทางเลือกใช้ controller ตัวที่ 1
router.get('/server', auth('admin','evaluator','evaluatee'), ctrl.listServer);
router.get('/', auth('admin','evaluator','evaluatee'), ctrl.list);
router.get('/:id', ctrl.get);
router.post('/', ctrl.create);
router.put('/:id?', ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;
