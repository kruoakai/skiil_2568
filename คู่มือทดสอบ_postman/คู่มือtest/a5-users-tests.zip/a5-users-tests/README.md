# A5 Users Routes — Jest/Supertest Complete Use Cases

## Run
```bash
npm install
npm test
# หรือ
npm run test:watch
```

## Start server (optional)
```bash
npm start
# http://localhost:7000
```

## Notes
- ใช้ `JWT_SECRET=changeme` โดยปริยายใน middleware
- เส้นทางผู้ใช้ตามที่ระบุ:
  - `/api/users/list2` (GET, ต้องมี token บทบาท admin/evaluator/evaluatee)
  - `/api/users/server2` (GET, ต้องมี token)
  - `/api/users/list2/:id` (GET, public)
  - `/api/users/server` (GET, ต้องมี token)
  - `/api/users/` (GET, ต้องมี token)
  - `/api/users/:id` (GET, public)
  - `/api/users` (POST, public)
  - `/api/users/:id?` (PUT, public; ไม่มี id -> 400)
  - `/api/users/:id` (DELETE, public)
