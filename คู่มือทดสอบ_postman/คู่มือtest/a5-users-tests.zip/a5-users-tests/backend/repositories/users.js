const fs = require('fs'); const path = require('path');
const DATA = path.join(__dirname, '..', 'data_users.json');

function readAll(){
  try { return JSON.parse(fs.readFileSync(DATA,'utf-8')); } catch { return []; }
}
function writeAll(list){ fs.writeFileSync(DATA, JSON.stringify(list, null, 2)); }

exports.reset = (rows=[])=> writeAll(rows);

exports.create = ({ name, email, role, password })=>{
  const list = readAll();
  const id = (list[list.length-1]?.id || 0) + 1;
  const now = new Date().toISOString();
  const row = { id, name, email, role, password, created_at: now };
  list.push(row); writeAll(list);
  return row;
};

exports.update = (id, patch)=>{
  const list = readAll();
  const idx = list.findIndex(x=> x.id === Number(id));
  if (idx === -1) return null;
  list[idx] = { ...list[idx], ...patch };
  writeAll(list);
  return list[idx];
};

exports.remove = (id)=>{
  const list = readAll();
  const idx = list.findIndex(x=> x.id === Number(id));
  if (idx === -1) return false;
  const [row] = list.splice(idx,1);
  writeAll(list);
  return row;
};

exports.findById = (id)=> readAll().find(x=> x.id === Number(id));
exports.list = ()=> readAll();
