const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors({ origin: (process.env.CORS_ORIGIN || '').split(',').filter(Boolean) }));

// routes
app.get('/health', (req,res)=> res.json({ ok:true }));
app.use('/api/users', require('./routes/users.routes'));

// 404 fallback (only for non-matched routes in tests)
app.use((req,res)=> res.status(404).json({ success:false, message:'Not Found' }));

module.exports = app;
