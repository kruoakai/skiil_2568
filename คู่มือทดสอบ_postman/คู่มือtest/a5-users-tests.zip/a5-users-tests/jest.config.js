/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>/tests'],
  verbose: true,
  collectCoverageFrom: [
    'backend/controllers/**/*.js',
    'backend/routes/**/*.js',
    'backend/middlewares/**/*.js',
    'backend/repositories/**/*.js'
  ]
};
