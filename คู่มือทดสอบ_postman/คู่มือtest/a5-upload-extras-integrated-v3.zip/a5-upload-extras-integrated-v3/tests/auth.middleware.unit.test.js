const auth = require('../backend-minimal/middlewares/auth');
const crypto = require('crypto');

function signJWT(payload, secret='changeme'){
  const header = Buffer.from(JSON.stringify({alg:'HS256', typ:'JWT'})).toString('base64url');
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

test('auth returns 401 when missing token', ()=>{
  const mw = auth('admin');
  const req = { headers:{} };
  const res = { statusCode:200, status(c){ this.statusCode=c; return this; }, json(o){ this.payload=o; } };
  mw(req,res,()=>{});
  expect(res.statusCode).toBe(401);
});

test('auth returns 403 when role not allowed', ()=>{
  const mw = auth('admin');
  const token = signJWT({ sub:1, role:'evaluatee', exp: 1893456000 });
  const req = { headers:{ authorization: `Bearer ${token}` } };
  const res = { statusCode:200, status(c){ this.statusCode=c; return this; }, json(o){ this.payload=o; } };
  mw(req,res,()=>{});
  expect(res.statusCode).toBe(403);
});

test('auth passes when role allowed', (done)=>{
  const mw = auth('admin','evaluatee');
  const token = signJWT({ sub:1, role:'evaluatee', exp: 1893456000 });
  const req = { headers:{ authorization: `Bearer ${token}` } };
  const res = { statusCode:200, status(c){ this.statusCode=c; return this; }, json(o){ this.payload=o; } };
  mw(req,res,()=>{ done(); });
});
