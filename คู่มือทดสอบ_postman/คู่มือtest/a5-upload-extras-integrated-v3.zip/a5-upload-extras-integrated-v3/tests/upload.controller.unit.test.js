const ctrl = require('../backend-minimal/controllers/upload.controller');

jest.mock('../backend-minimal/repositories/indicatorEvidence', ()=> ({
  isAllowed: jest.fn(()=> false)
}));

test('uploadSelf should return 415 when mapping invalid', ()=>{
  const req = { body: { period_id:1001, indicator_id:23, evidence_type_id:9 }, user:{ sub:101 } };
  const res = {
    statusCode: 200,
    status(c){ this.statusCode = c; return this; },
    jsonPayload: null,
    json(o){ this.jsonPayload = o; return this; }
  };
  ctrl.uploadSelf(req, res);
  expect(res.statusCode).toBe(415);
});
