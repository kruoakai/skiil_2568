const fs = require('fs');
const path = require('path');
const repo = require('../backend-minimal/repositories/users');
const p = path.join(__dirname, '..', 'backend-minimal', 'data_users.json');

beforeEach(()=>{
  fs.writeFileSync(p, JSON.stringify([
    { id:1, name:'A', email:'a@example.com', role:'evaluatee' }
  ], null, 2));
});

test('create increments id & persists', ()=>{
  const r = repo.create({ name:'B', email:'b@example.com', role:'admin' });
  expect(r.id).toBe(2);
  const all = repo.list();
  expect(all.length).toBe(2);
});

test('update returns null when id not found', ()=>{
  const u = repo.update(999, { name:'X' });
  expect(u).toBeNull();
});

test('remove returns false when id not found', ()=>{
  const ok = repo.remove(999);
  expect(ok).toBe(false);
});

test('findById returns object when exists', ()=>{
  const r = repo.findById(1);
  expect(r.email).toBe('a@example.com');
});
