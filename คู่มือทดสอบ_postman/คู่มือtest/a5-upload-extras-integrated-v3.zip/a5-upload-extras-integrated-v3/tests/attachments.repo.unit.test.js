const fs = require('fs');
const path = require('path');
const repo = require('../backend-minimal/repositories/attachments');
const p = path.join(__dirname, '..', 'backend-minimal', 'data_attachments.json');

beforeEach(()=>{
  fs.writeFileSync(p, JSON.stringify([], null, 2));
});

test('create + query + update + remove', ()=>{
  const row = repo.create({ period_id:1001, evaluatee_id:101, indicator_id:23, evidence_type_id:1, file_name:'a.pdf', mime_type:'application/pdf', size_bytes:10, storage_path:'/tmp/a.pdf' });
  expect(row.id).toBe(1);
  let list = repo.query({ period_id:1001, evaluatee_id:101 });
  expect(list.length).toBe(1);
  const updated = repo.update(1, { indicator_id: 31 });
  expect(updated.indicator_id).toBe(31);
  const removed = repo.remove(1);
  expect(removed.id).toBe(1);
  list = repo.query({ period_id:1001, evaluatee_id:101 });
  expect(list.length).toBe(0);
});

test('update returns null if not found; remove returns false if not found', ()=>{
  expect(repo.update(999, { a:1 })).toBeNull();
  expect(repo.remove(999)).toBe(false);
});
