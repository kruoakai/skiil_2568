const request = require('supertest');
const fs = require('fs');
const path = require('path');
const app = require('../backend-minimal/app');

function b64urlJSON(obj){ return Buffer.from(JSON.stringify(obj)).toString('base64url'); }
function signJWT(payload, secret='changeme'){
  const header = { alg:'HS256', typ:'JWT' };
  const h = b64urlJSON(header); const p = b64urlJSON(payload);
  const crypto = require('crypto');
  const sig = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}

const TOKENS = {
  evaluatee101: signJWT({ sub:101, role:'evaluatee', exp: 1893456000 }),
  admin1:       signJWT({ sub:1,   role:'admin',     exp: 1893456000 }),
};

const attachmentsDataPath = path.join(__dirname, '..', 'backend-minimal', 'data_attachments.json');

beforeEach(()=>{
  fs.writeFileSync(attachmentsDataPath, JSON.stringify([], null, 2));
});

test('listMine -> 400 when missing period_id', async ()=>{
  const res = await request(app).get('/api/upload/mine')
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`);
  expect(res.status).toBe(400);
});

test('replaceFile -> 400 when missing file', async ()=>{
  const buf = Buffer.from('%PDF-1.4\n%mock');
  let res = await request(app).post('/api/upload/evidence')
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`)
    .field('period_id','1001').field('indicator_id','23').field('evidence_type_id','1')
    .attach('file', buf, { filename:'a.pdf', contentType: 'application/pdf' });
  const id = res.body.data.id;
  res = await request(app).put(`/api/upload/${id}/file`)
    .set('Authorization', `Bearer ${TOKENS.evaluatee101}`);
  expect(res.status).toBe(400);
});

test('delete -> 404 when not found', async ()=>{
  const res = await request(app).delete('/api/upload/999')
    .set('Authorization', `Bearer ${TOKENS.admin1}`);
  expect(res.status).toBe(404);
});
