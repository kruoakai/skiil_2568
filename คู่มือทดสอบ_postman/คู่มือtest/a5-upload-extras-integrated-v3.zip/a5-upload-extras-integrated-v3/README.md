# A5 Upload + Users — Integrated v3 (Docs + Unit/E2E + Postman + CI)

## Run server
```bash
cd backend-minimal
cp .env.example .env
npm install
npm start   # http://localhost:7000  | Swagger: /docs
```

## Run tests (Jest — unit + e2e)
```bash
npm --prefix backend-minimal install
npm --prefix backend-minimal run test
# watch
npm --prefix backend-minimal run test:watch
```

## Docs (MkDocs Material)
```bash
python -m pip install mkdocs-material
mkdocs serve
# http://127.0.0.1:8000
```

## Postman/Newman
```bash
# Start server first
npm --prefix backend-minimal start &
npx newman run postman/A5_Smoke.postman_collection.json -e postman/A5_Upload_Env.postman_environment.json
npx newman run postman/A5_Upload_API_Full.postman_collection.json -e postman/A5_Upload_Env.postman_environment.json
```

## CI (GitHub Actions)
- Workflow: `.github/workflows/ci.yml`
- Jobs: install → Jest+coverage → start server → Newman (smoke + upload with fixtures)

## Notes
- Mock persistence: JSON files under `backend-minimal/`
- Indicator↔evidence mapping allowed: `23:1`, `31:2`
- Sample assignments: evaluator `201` ↔ evaluatee `101`, `55` in period `1001`
