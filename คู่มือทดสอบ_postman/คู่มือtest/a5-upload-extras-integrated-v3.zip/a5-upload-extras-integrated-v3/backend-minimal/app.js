const express = require('express');
const fs = require('fs'); const path = require('path');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');

const app = express();
app.use(express.json());
app.use(cors({ origin: (process.env.CORS_ORIGIN || '').split(',').filter(Boolean) }));

// static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  immutable: true, maxAge: '30d',
  setHeaders: (res) => res.setHeader('X-Content-Type-Options','nosniff')
}));

// routes
app.get('/health', (req,res)=> res.json({ ok:true }));
app.use('/api/upload', require('./routes/upload.routes'));
app.use('/api/users', require('./routes/users.routes'));

// swagger
try {
  const openapi = JSON.parse(fs.readFileSync(path.join(__dirname, 'openapi_full.json'), 'utf-8'));
  app.get('/openapi.json', (req,res)=> res.json(openapi));
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi));
} catch(e) {
  try {
    const content = fs.readFileSync(path.join(__dirname, '..', 'openapi_full.json'), 'utf-8');
    fs.writeFileSync(path.join(__dirname, 'openapi_full.json'), content);
    const openapi = JSON.parse(content);
    app.get('/openapi.json', (req,res)=> res.json(openapi));
    app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi));
  } catch(e2) {}
}

// error handler
app.use((err, req, res, next)=>{
  if (!err) return next();
  if (err.message === 'Unsupported file type') return res.status(415).json({ success:false, message: err.message });
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ success:false, message: 'File too large' });
  return res.status(400).json({ success:false, message: err.message });
});

module.exports = app;
