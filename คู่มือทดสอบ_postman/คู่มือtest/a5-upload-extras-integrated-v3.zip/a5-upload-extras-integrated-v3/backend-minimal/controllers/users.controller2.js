const usersRepo = require('../repositories/users');

exports.list2 = (req, res)=>{
  res.json({ success:true, data: usersRepo.list() });
};

exports.listServer = (req, res)=>{
  res.json({ success:true, data: { uptime: process.uptime(), tag:'server2' } });
};

exports.get = (req, res)=>{
  const row = usersRepo.findById(req.params.id);
  if (!row) return res.status(404).json({ success:false, message:'Not Found' });
  res.json({ success:true, data: row });
};
