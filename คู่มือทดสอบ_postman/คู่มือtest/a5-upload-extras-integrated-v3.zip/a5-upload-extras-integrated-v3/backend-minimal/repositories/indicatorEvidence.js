const allowed = new Set(['23:1','31:2']);
exports.isAllowed = (indicator_id, evidence_type_id)=> allowed.has(`${indicator_id}:${evidence_type_id}`);
