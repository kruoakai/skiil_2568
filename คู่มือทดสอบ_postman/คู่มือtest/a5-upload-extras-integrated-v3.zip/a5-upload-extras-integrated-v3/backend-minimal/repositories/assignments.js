const rows = [
  { period_id: 1001, evaluator_id: 201, evaluatee_id: 101 },
  { period_id: 1001, evaluator_id: 201, evaluatee_id: 55 },
];
exports.hasEvaluatee = (period_id, evaluator_id, evaluatee_id)=>{
  return rows.some(r => r.period_id == period_id && r.evaluator_id == evaluator_id && r.evaluatee_id == evaluatee_id);
};
