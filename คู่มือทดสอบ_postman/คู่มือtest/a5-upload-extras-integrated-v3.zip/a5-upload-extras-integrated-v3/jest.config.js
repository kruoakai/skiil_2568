/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>/tests'],
  verbose: true,
  collectCoverageFrom: [
    'backend-minimal/controllers/**/*.js',
    'backend-minimal/routes/**/*.js',
    'backend-minimal/middlewares/**/*.js',
    'backend-minimal/repositories/**/*.js'
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 80,
      lines: 80,
      statements: 80
    }
  }
};
