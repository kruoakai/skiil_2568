# A5 Upload Routes – Jest + Supertest Test Suite (Ready to Run)

## Files
- `jest.config.js`
- `app.js` (ตัวอย่าง – หากโปรเจกต์คุณมี `app.js` อยู่แล้ว ให้ใช้ของคุณแทน)
- `tests/setup.js`, `tests/support/store.js`
- `tests/evaluatee.spec.js`, `tests/evaluator.spec.js`, `tests/admin.spec.js`

## วิธีใช้งาน
1. คัดลอกโฟลเดอร์/ไฟล์ทั้งหมดไปไว้ที่ root โปรเจกต์ (ให้ `app.js`, `routes/`, `controllers/` อยู่ผังเดียวกัน)
2. ตรวจสอบว่าในโปรเจกต์ของคุณมี `routes/upload.routes.js` และ `controllers/upload.controller.js` ตามที่ใช้อยู่จริง
3. ติดตั้งแพ็กเกจทดสอบ:
   ```bash
   npm i -D jest supertest
   ```
4. เพิ่ม script:
   ```json
   "scripts": {
     "test": "jest --runInBand",
     "test:watch": "jest --watch",
     "test:cov": "jest --coverage"
   }
   ```
5. รันเทส:
   ```bash
   npm test
   # หรือ
   npm run test:cov
   ```

> หมายเหตุ: ในเทสมีการ mock โมดูลด้วย `jest.mock(path.join(root, ...))`
> เพื่อให้ path ที่ mock ตรงกับโมดูลจริงของคุณ ตรวจสอบว่าโครงสร้างโฟลเดอร์เหมือนกับ:
>
> ```
> project/
>  ├─ app.js
>  ├─ routes/
>  │   └─ upload.routes.js
>  ├─ controllers/
>  │   └─ upload.controller.js
>  ├─ middlewares/
>  │   ├─ auth.js
>  │   └─ upload.js
>  ├─ repositories/
>  │   ├─ attachments.js
>  │   ├─ assignments.js
>  │   └─ indicatorEvidence.js
>  └─ db/
>      └─ knex.js
> ```
