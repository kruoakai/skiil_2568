const path = require('path');
const root = path.resolve(__dirname, '..');

jest.mock(path.join(root, 'middlewares', 'auth'), () => {
  return (...allowedRoles) => {
    return (req, res, next) => {
      const role = req.header('x-test-role') || 'guest';
      const id = Number(req.header('x-test-user-id') || 0);
      req.user = { id, role };
      if (allowedRoles.length && !allowedRoles.includes(role)) {
        return res.status(403).json({ success:false, message:'Forbidden (mock)' });
      }
      next();
    };
  };
});

jest.mock(path.join(root, 'middlewares', 'upload'), () => ({
  single: () => (req,res,next)=> next()
}));

jest.mock(path.join(root, 'repositories', 'attachments'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  return { async findById(id){ return store.attachments.find(a=>a.id===Number(id)) || null; } };
});
jest.mock(path.join(root, 'repositories', 'assignments'), () => ({ async hasEvaluateeInPeriod(){ return true; } }));
jest.mock(path.join(root, 'repositories', 'indicatorEvidence'), () => ({ async mapExists(){ return true; } }));

jest.mock(path.join(root, 'db', 'knex'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  function table(name){
    const qb = {
      _name:name, _wheres:[],
      where(c){ this._wheres.push(c); return this; },
      andWhere(c){ this._wheres.push(c); return this; },
      orderBy(){ return this; },
      then(res){
        if(name==='attachments'){
          let rows=store.attachments.slice();
          for(const c of this._wheres){ rows=rows.filter(r=>Object.keys(c).every(k=>r[k]===c[k])); }
          return res(rows);
        }
        return res([]);
      }
    };
    return qb;
  }
  return table;
});

const request = require('supertest');
const app = require(path.join(root, 'app'));
const store = require(path.join(root, 'tests', 'support', 'store'));

describe('Evaluator Endpoints', () => {
  beforeEach(()=> store.reset());

  test('GET /evaluatee/:evaluateeId → list only that evaluatee', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, storage_path:'a' },
      { id:2, period_id:1, evaluatee_id:11, storage_path:'b' },
    ];
    const res = await request(app)
      .get('/api/uploads/evaluatee/10')
      .set('x-test-role','evaluator')
      .set('x-test-user-id','77');
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(1);
    expect(res.body.data[0].evaluatee_id).toBe(10);
  });
});
