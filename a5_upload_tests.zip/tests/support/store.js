// In-memory store used by mocks
let seq = 1;
let attachments = []; // { id, period_id, evaluatee_id, indicator_id, evidence_type_id, storage_path, file_name, mime_type, size_bytes }
let evaluation_periods = [
  { id: 1, is_active: 1 },
  { id: 2, is_active: 0 },
];

module.exports = {
  nextId: () => seq++,
  get attachments() { return attachments; },
  set attachments(v) { attachments = v; },
  evaluation_periods,
  reset() {
    seq = 1;
    attachments = [];
    evaluation_periods[0].is_active = 1;
    evaluation_periods[1].is_active = 0;
  }
};
