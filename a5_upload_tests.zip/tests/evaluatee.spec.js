// Evaluatee test suite (E2E/functional via Supertest)
const path = require('path');
const root = path.resolve(__dirname, '..'); // project root

// Inline manual mocks resolved by absolute path to match modules required by app/routes/controllers
jest.mock(path.join(root, 'middlewares', 'auth'), () => {
  return (...allowedRoles) => {
    return (req, res, next) => {
      const role = req.header('x-test-role') || 'guest';
      const id = Number(req.header('x-test-user-id') || 0);
      req.user = { id, role };
      if (allowedRoles.length && !allowedRoles.includes(role)) {
        return res.status(403).json({ success:false, message:'Forbidden (mock)' });
      }
      next();
    };
  };
});

jest.mock(path.join(root, 'middlewares', 'upload'), () => ({
  single: (fieldname) => (req, res, next) => {
    const meta = req.header('x-test-file');
    if (meta) {
      try {
        const obj = JSON.parse(meta);
        req.file = {
          originalname: obj.originalname || 'test.bin',
          mimetype: obj.mimetype || 'application/octet-stream',
          size: obj.size || 1,
          path: obj.path || path.join(__dirname, 'fake', 'test.bin'),
        };
      } catch {}
    }
    next();
  }
}));

jest.mock(path.join(root, 'repositories', 'attachments'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  return {
    async findById(id) {
      return store.attachments.find(a => a.id === Number(id)) || null;
    }
  };
});

jest.mock(path.join(root, 'repositories', 'assignments'), () => ({
  async hasEvaluateeInPeriod({ period_id, evaluatee_id }) {
    return Number(period_id) === 1 && Number(evaluatee_id) > 0;
  }
}));

jest.mock(path.join(root, 'repositories', 'indicatorEvidence'), () => ({
  async mapExists({ indicator_id, evidence_type_id }) {
    return Number(indicator_id) !== Number(evidence_type_id);
  }
}));

jest.mock(path.join(root, 'db', 'knex'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  function table(name) {
    if (name === 'attachments') {
      return {
        insert: async (obj) => {
          const id = store.nextId();
          store.attachments.push({ id, ...obj });
          return [id];
        },
        where: (cond) => ({
          update: async (set) => {
            store.attachments = store.attachments.map(r =>
              Object.keys(cond).every(k => r[k] === cond[k]) ? { ...r, ...set } : r
            );
          },
          del: async () => {
            store.attachments = store.attachments.filter(r =>
              !Object.keys(cond).every(k => r[k] === cond[k])
            );
          }
        })
      };
    }
    if (name === 'evaluation_periods') {
      return {
        where: (cond) => ({
          first: async () => {
            return store.evaluation_periods.find(r =>
              Object.keys(cond).every(k => r[k] === cond[k])
            ) || null;
          }
        })
      };
    }
    const qb = {
      _name: name,
      _wheres: [],
      where(cond){ this._wheres.push(cond); return this; },
      andWhere(cond){ this._wheres.push(cond); return this; },
      orderBy(){ return this; },
      then(res){ // allow await
        if (name === 'attachments') {
          let rows = store.attachments.slice();
          for (const c of this._wheres) {
            rows = rows.filter(r => Object.keys(c).every(k => r[k] === c[k]));
          }
          return res(rows);
        }
        return res([]);
      }
    };
    return qb;
  }
  return table;
});

const request = require('supertest');
const app = require(path.join(root, 'app')); // require your app.js
const store = require(path.join(root, 'tests', 'support', 'store'));

describe('Evaluatee Endpoints', () => {
  beforeEach(() => store.reset());

  test('POST /evidence → success', async () => {
    const res = await request(app)
      .post('/api/uploads/evidence')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10')
      .set('x-test-file', JSON.stringify({}))
      .send({ period_id: 1, indicator_id: 101, evidence_type_id: 102 });
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
  });

  test('POST /evidence → no file', async () => {
    const res = await request(app)
      .post('/api/uploads/evidence')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','11')
      .send({ period_id: 1, indicator_id: 101, evidence_type_id: 102 });
    expect(res.status).toBe(400);
  });

  test('POST /evidence → not assigned', async () => {
    const res = await request(app)
      .post('/api/uploads/evidence')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','0')
      .set('x-test-file', JSON.stringify({}))
      .send({ period_id: 1, indicator_id: 101, evidence_type_id: 102 });
    expect(res.status).toBe(400);
  });

  test('POST /evidence → period closed', async () => {
    const res = await request(app)
      .post('/api/uploads/evidence')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','12')
      .set('x-test-file', JSON.stringify({}))
      .send({ period_id: 2, indicator_id: 101, evidence_type_id: 102 });
    expect(res.status).toBe(403);
  });

  test('POST /evidence → invalid map', async () => {
    const res = await request(app)
      .post('/api/uploads/evidence')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','13')
      .set('x-test-file', JSON.stringify({}))
      .send({ period_id: 1, indicator_id: 5, evidence_type_id: 5 });
    expect(res.status).toBe(400);
  });

  test('GET /mine → list only self', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, indicator_id:1, evidence_type_id:2, storage_path:'a' },
      { id:2, period_id:1, evaluatee_id:99, indicator_id:1, evidence_type_id:2, storage_path:'b' },
    ];
    const res = await request(app)
      .get('/api/uploads/mine')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10');
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(1);
    expect(res.body.data[0].evaluatee_id).toBe(10);
  });

  test('DELETE /:id → delete self success', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, indicator_id:1, evidence_type_id:2, storage_path:'p1' },
    ];
    const res = await request(app)
      .delete('/api/uploads/1')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10');
    expect(res.status).toBe(200);
    expect(store.attachments.length).toBe(0);
  });

  test('DELETE /:id → cannot delete others', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:99, indicator_id:1, evidence_type_id:2, storage_path:'p1' },
    ];
    const res = await request(app)
      .delete('/api/uploads/1')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10');
    expect(res.status).toBe(404);
    expect(store.attachments.length).toBe(1);
  });

  test('PUT /:id/file → update file success', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, storage_path:'old.pdf' },
    ];
    const res = await request(app)
      .put('/api/uploads/1/file')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10')
      .set('x-test-file', JSON.stringify({}));
    expect(res.status).toBe(200);
  });

  test('PATCH /:id → update meta invalid map', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, indicator_id:1, evidence_type_id:2, storage_path:'f.pdf' },
    ];
    const res = await request(app)
      .patch('/api/uploads/1')
      .set('x-test-role','evaluatee')
      .set('x-test-user-id','10')
      .send({ indicator_id: 5, evidence_type_id: 5 });
    expect(res.status).toBe(400);
  });
});
