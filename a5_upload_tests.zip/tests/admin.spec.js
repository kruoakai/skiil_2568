const path = require('path');
const root = path.resolve(__dirname, '..');

jest.mock(path.join(root, 'middlewares', 'auth'), () => {
  return (...allowedRoles) => {
    return (req, res, next) => {
      const role = req.header('x-test-role') || 'guest';
      const id = Number(req.header('x-test-user-id') || 0);
      req.user = { id, role };
      if (allowedRoles.length && !allowedRoles.includes(role)) {
        return res.status(403).json({ success:false, message:'Forbidden (mock)' });
      }
      next();
    };
  };
});

jest.mock(path.join(root, 'middlewares', 'upload'), () => ({
  single: () => (req,res,next)=> { req.file = req.file || { originalname:'a', mimetype:'x', size:1, path: path.join(__dirname,'fake.bin') }; next(); }
}));

jest.mock(path.join(root, 'repositories', 'attachments'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  return { async findById(id){ return store.attachments.find(a=>a.id===Number(id)) || null; } };
});
jest.mock(path.join(root, 'repositories', 'assignments'), () => ({
  async hasEvaluateeInPeriod({ period_id, evaluatee_id }) {
    return Number(period_id) === 1 && Number(evaluatee_id) > 0;
  }
}));
jest.mock(path.join(root, 'repositories', 'indicatorEvidence'), () => ({
  async mapExists({ indicator_id, evidence_type_id }) {
    return Number(indicator_id) !== Number(evidence_type_id);
  }
}));

jest.mock(path.join(root, 'db', 'knex'), () => {
  const store = require(path.join(root, 'tests', 'support', 'store'));
  function table(name){
    if(name==='attachments'){
      return {
        insert: async(obj)=>{ const id=store.nextId(); store.attachments.push({id,...obj}); return [id]; },
        where: (cond)=>({
          update: async(set)=>{ store.attachments = store.attachments.map(r=> Object.keys(cond).every(k=>r[k]===cond[k])? {...r,...set}: r); },
          del: async()=>{ store.attachments = store.attachments.filter(r=> !Object.keys(cond).every(k=>r[k]===cond[k])); }
        })
      };
    }
    const qb = {
      _name:name,_wheres:[],
      where(c){ this._wheres.push(c); return this; },
      andWhere(c){ this._wheres.push(c); return this; },
      orderBy(){ return this; },
      then(res){
        if(name==='attachments'){
          let rows=store.attachments.slice();
          for(const c of this._wheres){ rows=rows.filter(r=>Object.keys(c).every(k=>r[k]===c[k])); }
          return res(rows);
        }
        return res([]);
      }
    };
    return qb;
  }
  return table;
});

const request = require('supertest');
const app = require(path.join(root, 'app'));
const store = require(path.join(root, 'tests', 'support', 'store'));

describe('Admin Endpoints', () => {
  beforeEach(()=> store.reset());

  test('POST /admin/evidence → success', async () => {
    const res = await request(app)
      .post('/api/uploads/admin/evidence')
      .set('x-test-role','admin')
      .set('x-test-user-id','1')
      .send({ evaluatee_id: 10, period_id: 1, indicator_id: 3, evidence_type_id: 4 });
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(store.attachments.length).toBe(1);
  });

  test('GET /admin → list all', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, storage_path:'a' },
      { id:2, period_id:1, evaluatee_id:20, storage_path:'b' },
    ];
    const res = await request(app)
      .get('/api/uploads/admin')
      .set('x-test-role','admin');
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(2);
  });

  test('DELETE /admin/:id', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, storage_path:'a' },
    ];
    const res = await request(app)
      .delete('/api/uploads/admin/1')
      .set('x-test-role','admin');
    expect(res.status).toBe(200);
    expect(store.attachments.length).toBe(0);
  });

  test('PUT /admin/:id/file → update file', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, storage_path:'old.pdf' },
    ];
    const res = await request(app)
      .put('/api/uploads/admin/1/file')
      .set('x-test-role','admin');
    expect(res.status).toBe(200);
  });

  test('PATCH /admin/:id → invalid map', async () => {
    store.attachments = [
      { id:1, period_id:1, evaluatee_id:10, indicator_id:1, evidence_type_id:2, storage_path:'f.pdf' },
    ];
    const res = await request(app)
      .patch('/api/uploads/admin/1')
      .set('x-test-role','admin')
      .send({ indicator_id:5, evidence_type_id:5 });
    expect(res.status).toBe(400);
  });
});
