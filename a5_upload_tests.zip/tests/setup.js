process.env.JWT_SECRET = 'test-secret';
const store = require('./support/store');
beforeEach(() => {
  store.reset();
});
