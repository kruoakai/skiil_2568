// Sample app.js for testing; adjust paths if needed
const express = require('express');
const app = express();
app.use(express.json());

// Mount your uploads routes
app.use('/api/uploads', require('./routes/upload.routes'));

// Optional: error handler (keeps test output clean)
app.use((err, req, res, next) => {
  const status = err.status || 500;
  res.status(status).json({ success:false, message: err.message || 'error' });
});

module.exports = app;
