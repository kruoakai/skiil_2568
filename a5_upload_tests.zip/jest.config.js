module.exports = {
  testEnvironment: 'node',
  setupFilesAfterEnv: ['<rootDir>/tests/setup.js'],
  testMatch: ['**/tests/**/*.spec.js'],
  resetMocks: true,
  restoreMocks: true,
  clearMocks: true,
};
